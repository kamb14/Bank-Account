//SUPERCLASS

public class BankAccount {

    //variables
    private String holderName;
    private String accountNumber;
    private double balance;
    private double savings;

    //main constructor w/ parameters
    public  BankAccount(String holderName, String accountNumber, double balance, double savings){

        //THIS STATEMENT TO TELL THE PROGRAM WHAT VARIABLE TO LOOK FOR
        this.holderName = holderName;
        this.accountNumber = accountNumber;
        this.balance = balance;
        this.savings = savings;
    }

    //CALCULATE BALANCE
    public void depositCHK(double amount){

        balance = balance + amount;

    }

    //CALCULATE SAVINGS 
    public void depositSAV(double total){

        savings = savings + total;

    }

    //CALCULATE WITHDRAWAL AMT FROM CHECKING FOR INSUFFICIENT FUNDS
    public void withdrawCHK(double amount){
        
        //if else statment
        if(balance >= amount){
            balance -= amount;

        }else{
            System.out.println("You have an insufficient balance.");
        }

    }

    //CALCULATE WITHDRAWAL AMT FROM SAVINGS FOR INSUFFICIENT FUNDS
    public void withdrawSAV(double total){

        if(savings >= total){
            savings-=total;

        }else{
            System.out.println("You have an insufficient balance.");
        }
    }

    //GET BALANCE AMT
    public double getBalance(){

        return balance;
    }

    //GET SAVINGS AMT
    public double getSavings(){

        return savings;
    }

    //DISPLAYS ACCOUNT INFO
    public String display(){

        String message;

        message = "\nAccount Holder Name: " + holderName + 
        "\nAccount Number: " + accountNumber;

    
        return message;
    }
    
}
