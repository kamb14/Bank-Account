//SUPERCLASS: BANKACCOUNT.JAVA
//SUBCLASS

//extends from the bankaccount file
public class Account extends BankAccount{

    public Account(String holderName, String accountNumber, double balance, double savings){

        //calls method from bankaccount file
        super(holderName, accountNumber, balance, savings);
    }
        //overrides the withdrawchk from the first file
    @Override
    public void withdrawCHK(double amount){

        if(getBalance() - amount == 0 || getBalance() - amount < 0){

            System.out.println("ERROR! YOU CAN'T WITHDRAW THAT AMOUNT.");

        }else{

            super.withdrawCHK(getBalance());
            System.out.println("Amount withdrawn:" + getBalance());
        }
    }
        //overrides withdrawsav from first file
    @Override
         public void withdrawSAV(double total){

            if(getSavings() - total == 0 || getSavings() - total < 0){

                System.out.println("ERROR! YOU CAN'T WITHDRAW MORE THAN WHAT YOU HAVE.");
                
            }else{

                super.withdrawSAV(total);

                System.out.println("Withdrawal amount: " + total + " From Savings "+ super.getSavings());
            }
        }
}
