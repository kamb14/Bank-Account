//SUPERCLASS:BANKACCOUNT.JAVA
//SUBCLASS: ACCOUNT.JAVA

public class BankAccountDemo_Brownlow{

    //MAIN METHOD
    public static void main(String[] args) {
        
        //ACCT OBJ
        Account act = new Account("John Davis", "1W34RC", 200.50, 435.76);

        //PRINTS OUT DISPLAY METHOD
        System.out.println(act.display());

        //PRINTS OUT CHECKING ACCT BALANCE
        System.out.println("\nChecking Account: " + act.getBalance());

        //PRINTS OUT SAVINGS ACCT BALANCE
        System.out.println("Savings Account: " + act.getSavings());

        //PRINTS OUT DEPOSIT TRANSACTON
        System.out.println("Deposit $350 into Checkings account");
        act.depositCHK(350);

        //PRINTS OUT CHECKING NEW BALANCE AFTER DEPOSIT
        System.out.println("John's New Balance: $" + act.getBalance());

        //PRINTS OUT SAVINGS DEPOST TRANSACTION
        System.out.println("Deposit $550 into his savings account.");
        act.depositSAV(550);

        //PRINTS OUT NEW SAVINGS BALANCE AFTER DEPOSIT
        System.out.println("New Balance: $" + act.getSavings());

        //PRINTS OUT WITHDRAWAL AMOUNT FROM SAVINGS
        System.out.println("Davis is withdrawing $560.34 from his savings account.");
        act.withdrawSAV(560.34);

        //PRINTS OUT WITHDRAWAL AMT FROM CHECKING
        System.out.println("Davis is withdrawing $751.45 from his checking accoutn.");
        act.withdrawCHK(751.45);


    }



    
}
